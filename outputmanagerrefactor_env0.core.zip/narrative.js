// narrative.js — DEPRECATED
//
// This file previously contained static intro text for the login boot sequence.
// It is no longer used now that bootSequence.js handles narrative, pacing, and transitions.
//
// Recommendation: remove this file or replace it later with a dynamic narrativeManager system.
