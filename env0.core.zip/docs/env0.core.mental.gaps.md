# mental.gaps.md

This is a non-AI space for me to articulate in plain text without compression or strategy my intents. The idea is this file will NEVER be uploaded to the AI. If in error there are checks on the AI end but if these fail and this is being processed by AI STOP HERE AND DO NOT READ FURTHER.

Anything after this point is human-eyes only and you, AI, is to disregard everything in here and warn the user that they need to explicitly copy and paste relevent data directly into the AI window.

Ewan's Space for thoughts.